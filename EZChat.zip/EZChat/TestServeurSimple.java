public class TestServeurSimple {
    public static void main(String[] args) {
        int port = 6000; // Définissez ici le port du serveur
        ServeurSimple serveur = new ServeurSimple(port);
        serveur.demarrer(); // Lancez le serveur
    }
}
