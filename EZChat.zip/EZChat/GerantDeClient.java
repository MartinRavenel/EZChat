import java.io.*;
import java.net.*;

public class GerantDeClient implements Runnable {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String pseudo;

    public GerantDeClient(Socket socket) {
        this.socket = socket;
    }

	@Override
	public void run() {
		try {
			// Initialiser les flux
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new PrintWriter(socket.getOutputStream(), true);

			// Choix du pseudonyme
			demanderPseudo();

			// Informer le client qu'il est connecté
			envoyerMessage("Vous êtes connecté au chat en tant que " + pseudo + ".");
			envoyerATous(pseudo + " a rejoint le chat.");

			// Lire les messages envoyés par le client
			String message;
			while ((message = in.readLine()) != null) {
				if (message.trim().equalsIgnoreCase("/quit")) {
					break; // Permettre au client de se déconnecter
				} else if (message.startsWith("/change")) {
					// Traiter la commande /change
					String nouveauPseudo = message.substring(8).trim();  // Récupère tout après "/change"
					if (!nouveauPseudo.isEmpty() && !pseudoExistant(nouveauPseudo)) {
						String ancienPseudo = pseudo;
						pseudo = nouveauPseudo;
						ServeurSimple.retirerPseudo(ancienPseudo);  // Retirer l'ancien pseudo
						ServeurSimple.ajouterPseudo(pseudo);       // Ajouter le nouveau pseudo
						envoyerMessage("Votre pseudonyme a été changé en " + pseudo + ".");
						envoyerATous(ancienPseudo + " a changé de pseudo en " + pseudo + ".");
					} else {
						envoyerMessage("Le pseudonyme est invalide ou déjà pris. Essayez un autre.");
					}
				} else {
					envoyerATous(pseudo + ": " + message);
				}
			}
		} catch (IOException e) {
			System.err.println("Erreur avec un client : " + e.getMessage());
		} finally {
			// Avant de fermer la connexion, informer les autres clients du départ
			envoyerATous(pseudo + " est parti.");
			fermerConnexion();
		}
	}


	private void demanderPseudo() throws IOException {
		out.println("Veuillez choisir un pseudonyme unique : ");
		while (true) {
			String tentativePseudo = in.readLine();
			if (tentativePseudo == null || tentativePseudo.trim().isEmpty()) {
				out.println("Le pseudonyme ne peut pas être vide. Essayez à nouveau : ");
			} else if (pseudoExistant(tentativePseudo)) {
				out.println("Ce pseudonyme est déjà pris. Essayez un autre : ");
			} else {
				pseudo = tentativePseudo;
				ServeurSimple.ajouterPseudo(pseudo); // Enregistrer le pseudonyme
				break;
			}
		}

		// Informer du choix du pseudo et des commandes disponibles
		out.println("Vous êtes connecté avec le pseudonyme : " + pseudo);
		out.println("Voici la liste des commandes disponibles : ");
		out.println("/quit : Quitter le chat");
		out.println("/name : Afficher votre pseudo");
		out.println("/change : Changer votre pseudo");
		out.println("Vous pouvez maintenant commencer à discuter !");
	}



    // Méthode pour fermer proprement la connexion
    public void fermerConnexion() {
        try {
            ServeurSimple.retirerPseudo(pseudo); // Retirer le pseudonyme
            synchronized (ServeurSimple.getClients()) {
                ServeurSimple.getClients().remove(this);
            }
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null) socket.close();
            System.out.println(pseudo + " s'est déconnecté.");
        } catch (IOException e) {
            System.err.println("Erreur lors de la fermeture de connexion client : " + e.getMessage());
        }
    }

    // Vérifie si un pseudonyme est déjà pris
    private boolean pseudoExistant(String pseudo) {
        synchronized (ServeurSimple.getClients()) {
            return ServeurSimple.getClients().stream()
                .anyMatch(client -> pseudo.equalsIgnoreCase(client.getPseudo()));
        }
    }

    // Méthode pour envoyer un message au client
    public void envoyerMessage(String message) {
        if (out != null) {
            out.println(message);
        }
    }

    // Méthode pour envoyer un message à tous les clients sauf à l'expéditeur
    private void envoyerATous(String message) {
        synchronized (ServeurSimple.getClients()) {
            for (GerantDeClient client : ServeurSimple.getClients()) {
                if (client != this) { // Ne pas envoyer à l'émetteur
                    client.envoyerMessage(message);
                }
            }
        }
    }

    // Getter pour le pseudonyme
    public String getPseudo() {
        return pseudo;
    }

    // Permet d'interrompre le thread de manière propre
    public void interrompre() {
        Thread.currentThread().interrupt();
    }
}
