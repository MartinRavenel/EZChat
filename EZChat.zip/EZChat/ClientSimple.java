import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ClientSimple {
    private static final String SERVER_ADDRESS = "localhost"; // Adresse du serveur
    private static final int SERVER_PORT = 6000; // Port du serveur
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String pseudo;
    private Scanner scanner;

    public ClientSimple() {
        scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        ClientSimple client = new ClientSimple();
        client.connecterAuServeur();
        client.demanderPseudo();
        client.startThreadLecture();
        client.envoyerMessages();
    }

    // Se connecter au serveur
    public void connecterAuServeur() {
        try {
            socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            System.out.println("Connecté au serveur à " + SERVER_ADDRESS + ":" + SERVER_PORT);
        } catch (IOException e) {
            System.err.println("Erreur de connexion au serveur : " + e.getMessage());
        }
    }

    // Demander un pseudonyme à l'utilisateur
    public void demanderPseudo() {
        try {
            String message = in.readLine(); // Recevoir le message de bienvenue du serveur
            System.out.println(message); // Afficher ce message
            System.out.print("Entrez votre pseudonyme : ");
            pseudo = scanner.nextLine();
            out.println(pseudo); // Envoyer le pseudonyme au serveur
        } catch (IOException e) {
            System.err.println("Erreur lors de l'envoi du pseudonyme : " + e.getMessage());
        }
    }

    // Démarrer le thread pour lire les messages du serveur
    public void startThreadLecture() {
        Thread lecteurThread = new Thread(new Runnable() {
            @Override
            public void run() {
                lireMessagesServeur();  // Appeler la méthode lireMessagesServeur dans le thread
            }
        });
        lecteurThread.start();
    }

    // Lire les messages envoyés par le serveur
    public void lireMessagesServeur() {
        try {
            String message;
            while ((message = in.readLine()) != null) {
                System.out.println(message); // Afficher les messages du serveur
            }
        } catch (IOException e) {
            System.err.println("Erreur de communication avec le serveur : " + e.getMessage());
        }
    }

    // Gérer l'envoi de messages au serveur
    public void envoyerMessages() {
        while (true) {
            String message = scanner.nextLine(); // Lire le message saisi par l'utilisateur
            if (message.equalsIgnoreCase("/quit")) {
                out.println("/quit"); // Envoi de la commande pour quitter
                break;
            } else if (message.equalsIgnoreCase("/name")) {
                out.println("/name"); // Afficher le pseudo
            } else if (message.startsWith("/change")) {
                out.println(message); // Envoyer la commande de changement de pseudo
            } else {
                out.println(message); // Envoyer un message classique
            }
        }

        fermerConnexion(); // Fermer la connexion lorsque l'utilisateur quitte
    }

    // Fermer la connexion avec le serveur
    public void fermerConnexion() {
        try {
            socket.close();
            System.out.println("Déconnecté du serveur.");
        } catch (IOException e) {
            System.err.println("Erreur lors de la fermeture de la connexion : " + e.getMessage());
        }
    }
}
