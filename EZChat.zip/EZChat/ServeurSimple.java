import java.io.*;
import java.net.*;
import java.util.*;

public class ServeurSimple {
    private final int port; // Port du serveur
    private static final List<GerantDeClient> clients = new ArrayList<>();
    private static final List<String> pseudos = new ArrayList<>(); // Liste des pseudonymes actifs

    // Constructeur avec port
    public ServeurSimple(int port) {
        this.port = port;
    }

    public void demarrer() {
        System.out.println("Démarrage du serveur sur le port " + port + "...");
        System.out.println("Commandes disponibles :");
        System.out.println("/close - Fermer le serveur");
        System.out.println("/kick <pseudo> - Déconnecter un client");

        try (ServerSocket serverSocket = new ServerSocket(port);
             BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in))) {

            Thread consoleThread = new Thread(() -> {
                try {
                    while (true) {
                        String command = consoleInput.readLine();
                        if (command == null) continue;

                        if (command.equalsIgnoreCase("/close")) {
                            fermerServeur();
                            break;
                        } else if (command.startsWith("/kick ")) {
                            String pseudo = command.substring(6).trim();
                            kickClient(pseudo);
                        } else {
                            System.out.println("Commande inconnue. Commandes disponibles : /close, /kick <pseudo>");
                        }
                    }
                } catch (IOException e) {
                    System.err.println("Erreur de lecture de la console : " + e.getMessage());
                }
            });
            consoleThread.start();

            while (true) {
                Socket clientSocket = serverSocket.accept();
                GerantDeClient client = new GerantDeClient(clientSocket);
                synchronized (clients) {
                    clients.add(client);
                }
                new Thread(client).start();
            }
        } catch (IOException e) {
            System.err.println("Erreur sur le serveur : " + e.getMessage());
        }
    }

    // Fermer le serveur et notifier les clients
    private static void fermerServeur() {
        System.out.println("Fermeture du serveur...");
        synchronized (clients) {
            for (GerantDeClient client : clients) {
                client.envoyerMessage("Client expulsé : Le serveur est en cours d'arrêt.");
                client.fermerConnexion();
            }
            clients.clear();
        }
        System.out.println("Le serveur est arrêté.");
        System.exit(0);
    }

	private static void kickClient(String pseudo) {
		synchronized (clients) {
			GerantDeClient clientToKick = null;
			for (GerantDeClient client : clients) {
				if (pseudo.equalsIgnoreCase(client.getPseudo())) {
					clientToKick = client;
					break;
				}
			}

			if (clientToKick != null) {
				// Interruption du thread du client expulsé
				clientToKick.interrompre();

				// Envoi du message d'expulsion aux autres clients
				envoyerMessageATous(pseudo + " a été expulsé.");
				System.out.println("Client expulsé : " + pseudo);

				// Fermeture propre de la connexion
				clientToKick.envoyerMessage("Vous avez été déconnecté par l'administrateur.");
				clientToKick.fermerConnexion();

				// Retrait du client et de son pseudo
				clients.remove(clientToKick);
				retirerPseudo(clientToKick.getPseudo());
			} else {
				System.out.println("Aucun client avec le pseudonyme '" + pseudo + "' n'a été trouvé.");
			}
		}
	}



    // Envoyer un message à tous les clients
    private static void envoyerMessageATous(String message) {
        synchronized (clients) {
            for (GerantDeClient client : clients) {
                client.envoyerMessage(message);
            }
        }
    }

    // Accesseurs pour la liste des clients et pseudonymes
    public static List<GerantDeClient> getClients() {
        return clients;
    }

    public static void ajouterPseudo(String pseudo) {
        synchronized (pseudos) {
            pseudos.add(pseudo);
            afficherClientsActifs(); // Un seul appel ici
        }
    }

    public static void retirerPseudo(String pseudo) {
        synchronized (pseudos) {
            pseudos.remove(pseudo);
        }
    }

    public static void afficherClientsActifs() {
        synchronized (pseudos) {
            System.out.println("Clients actifs : " + String.join(", ", pseudos));
        }
    }
}
